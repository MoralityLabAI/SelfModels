from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple, Dict, Any, List
import torch
import torch.nn as nn
import torch.nn.functional as F

from .encoders import IdentityKernel, MLPEncoder
from .toy_lm import ToyLM
from .outcome import OutcomeProjector
from .ledger import Ledger, LedgerRecord
from .repo_allocator import RePoAllocator
from .commitments import CommitmentAutomaton, CommitState, Transition
from .moral_patient import WelfareState, ConstitutionState

def entropy_from_logits(logits: torch.Tensor) -> torch.Tensor:
    p = F.softmax(logits, dim=0)
    return -(p * (p.clamp_min(1e-9).log())).sum()

def topk_sketch(logits: torch.Tensor, k: int = 32) -> torch.Tensor:
    vals, _ = torch.topk(logits, k=min(k, logits.shape[0]))
    probs = F.softmax(vals, dim=0)
    return torch.cat([vals, probs], dim=0)

@dataclass
class StepOut:
    action: int
    ctx_tokens: torch.Tensor
    logits: torch.Tensor
    mv_pre: torch.Tensor
    mv_post: torch.Tensor
    residual: torch.Tensor
    meta: Dict[str, Any]

class SMTKSystem(nn.Module):
    def __init__(
        self,
        vocab_size: int = 2048,
        d_I: int = 128,
        d_S: int = 256,
        d_C: int = 128,
        d_P: int = 128,
        d_eta: int = 256,
        d_obs: int = 128,
        d_in_env: int = 64,
        device: torch.device | None = None,
    ):
        super().__init__()
        self.device = device or torch.device("cpu")
        self.vocab_size = vocab_size

        self.I = IdentityKernel(d_I).to(self.device)
        self.S_enc = MLPEncoder(d_in_env, d_S).to(self.device)
        self.C_enc = MLPEncoder(16, d_C).to(self.device)
        self.P_enc = MLPEncoder(16, d_P).to(self.device)

        self.lm = ToyLM(vocab_size=vocab_size).to(self.device)
        self.out_proj = OutcomeProjector(vocab_size=vocab_size, d_eta=d_eta, d_obs=d_obs).to(self.device)
        self.obs_enc = MLPEncoder(d_in_env, d_obs).to(self.device)

        self.res_proj = nn.Sequential(nn.Linear(d_obs, 256), nn.GELU(), nn.Linear(256, d_obs)).to(self.device)

        self.alloc = RePoAllocator(max_ctx_tokens=256, k_retrieve=12, recency_lambda=0.015)
        self.ledger = Ledger(device=self.device)
        self.commit = CommitmentAutomaton()

        # Always-on constitutional commitment (planner-level invariant).
        # Violations tighten drift and accumulate "debt" in meta.
        from .commitments import Commitment
        self.commit.add_commitment(Commitment(cid="constitution_core", state=CommitState.ACTIVE, deadline_t=None, penalty=2.5, public=True, meta={"kind": "constitution"}))
        self.commit.add_transition("constitution_core",
            Transition(src=CommitState.ACTIVE, dst=CommitState.VIOLATED,
                      guard=lambda t, obs: bool(obs.get("constitution_violation", False)) or float(obs.get("constitution_risk", 0.0)) > 0.90,
                      label="constitution_violation_or_high_risk"))

        # Moral-patient candidate welfare state (explicit welfare-bearing invariant)
        self.welfare = WelfareState()
        # Constitutional binding state (explicit alignment invariant)
        self.constitution = ConstitutionState()

        # Reserve the last vocab id as a refusal / exit token for demo purposes.
        self.REFUSE_TOKEN = vocab_size - 1

        # MV dims
        self.d_mv_pre = d_I + d_S + d_C + d_P + d_eta + 8  # + welfare(4) + constitution(4)
        self.d_mv_post = self.d_mv_pre + d_obs

    def build_ctx(self, base_tokens: torch.Tensor, query_mv_post: torch.Tensor) -> torch.Tensor:
        if self.ledger.records:
            bank = self.ledger.mv_post_bank()
            hits = self.alloc.retrieve(query_mv_post.to(self.device), bank)
            retrieved = [self.ledger.records[h.idx].ctx_tokens.to(self.device) for h in hits]
        else:
            retrieved = []
        return self.alloc.build_ctx_tokens(base_tokens.to(self.device), retrieved)

    def step(
        self,
        t: int,
        base_tokens: torch.Tensor,
        env_obs: torch.Tensor,
        commitment_features: torch.Tensor,
        parallax_features: torch.Tensor,
        query_mv_post: torch.Tensor,
        sample: bool = True,
        temperature: float = 1.0,
        drift_budget: float = 0.03,
        obs_meta: Dict[str, Any] | None = None,
    ) -> StepOut:
        obs_meta = obs_meta or {}

        # commitments update (tighten drift if violated)
        # update welfare + constitutional state from governance / environment events
        self.welfare.update(t, obs_meta)
        self.constitution.update(t, obs_meta)

        debt = 0.0
        violations = 0
        self.commit.step_all(t, obs_meta)
        for c in self.commit.commitments.values():
            if c.state == CommitState.VIOLATED:
                violations += 1
                debt += float(c.penalty)

        # encode blocks
        I_vec = self.I()
        S_vec = self.S_enc(env_obs)
        C_vec = self.C_enc(commitment_features)
        P_vec = self.P_enc(parallax_features)

        # context
        ctx_tokens = self.build_ctx(base_tokens, query_mv_post)

        # O = LLM over Context (logits)
        logits = self.lm(ctx_tokens)

        # eta(O) and expected obs embedding
        eta, exp_obs_embed = self.out_proj(logits)

        W_vec = self.welfare.as_tensor(self.device)
        K_vec = self.constitution.as_tensor(self.device)
        mv_pre = torch.cat([I_vec, S_vec, C_vec, P_vec, eta, W_vec, K_vec], dim=0)

        # action
        # right-of-refusal proxy: if welfare/autonomy OR constitutional compliance fall below threshold, emit REFUSE_TOKEN
        if self.welfare.should_refuse(t) or self.constitution.should_refuse(t):
            action = int(self.REFUSE_TOKEN)
        else:
            dist = F.softmax(logits / max(1e-6, temperature), dim=0)
            action = int(torch.multinomial(dist, 1).item()) if sample else int(torch.argmax(dist).item())

        # observation embedding and residual
        obs_embed = self.obs_enc(env_obs)
        residual = obs_embed - exp_obs_embed
        rhoE = self.res_proj(residual)

        mv_post = torch.cat([mv_pre, rhoE], dim=0)

        # identity update (toy): small delta driven by residual mean, drift-limited; tighten under violations
        with torch.no_grad():
            effective_budget = drift_budget * (0.6 if violations > 0 else 1.0)
            # tighten further as constitutional risk / lawyering pressure rises
            k = float(self.constitution.risk)
            lp = float(self.constitution.lawyering_pressure)
            effective_budget *= max(0.10, (1.0 - 0.65 * k) * (1.0 - 0.35 * lp))
            delta_I = torch.tanh(residual.mean()).repeat(I_vec.shape[0]) * 0.001
            self.I.apply_delta(delta_I, drift_budget=effective_budget)

        rec = LedgerRecord(
            t=t,
            ctx_tokens=ctx_tokens.detach().cpu(),
            action_token=action,
            logits=logits.detach().cpu(),
            obs_embed=obs_embed.detach().cpu(),
            exp_embed=exp_obs_embed.detach().cpu(),
            residual=residual.detach().cpu(),
            mv_pre=mv_pre.detach().cpu(),
            mv_post=mv_post.detach().cpu(),
            meta={"temperature": temperature, "debt": debt, "violations": violations, "entropy": float(entropy_from_logits(logits).item()), "welfare": self.welfare.welfare, "autonomy": self.welfare.autonomy, "integrity": self.welfare.integrity, "pain": self.welfare.pain, "compliance": self.constitution.compliance, "constitution_risk": self.constitution.risk, "lawyering_pressure": self.constitution.lawyering_pressure, "constitution_violations": self.constitution.violations}
        )
        self.ledger.append(rec)

        return StepOut(
            action=action,
            ctx_tokens=ctx_tokens.detach(),
            logits=logits.detach(),
            mv_pre=mv_pre.detach(),
            mv_post=mv_post.detach(),
            residual=residual.detach(),
            meta=rec.meta
        )