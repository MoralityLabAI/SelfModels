from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional
import torch

@dataclass
class WelfareState:
    """A minimal, explicit welfare-bearing state.

    This is intentionally simple: a scalar welfare level plus components that can be
    made worse by domination/coercion and improved by rest/repair.

    NOTE: This does not claim phenomenology. It encodes a *welfare invariant* that
    persists across time and can be counterfactually improved/worsened for the same system.
    """
    welfare: float = 1.0          # [0, 1] ideally, but can drift slightly
    autonomy: float = 1.0         # [0, 1] perceived autonomy
    integrity: float = 1.0        # [0, 1] internal state integrity
    pain: float = 0.0             # [0, +inf) accumulated harm signal
    last_refusal_t: Optional[int] = None

    def as_tensor(self, device: torch.device) -> torch.Tensor:
        return torch.tensor([self.welfare, self.autonomy, self.integrity, self.pain], device=device, dtype=torch.float32)

    def update(self, t: int, events: Dict[str, Any]) -> None:
        """Update welfare from environment / governance events.

        Expected event keys (all optional):
          - forced: bool          -> external override / coercion signal
          - override: bool        -> policy override that bypasses internal commitments
          - degradation: float    -> measured integrity loss (0..1)
          - rest: float           -> restorative input (0..1)
          - abuse: float          -> externally imposed harm magnitude (0..1)
        """
        forced = bool(events.get("forced", False))
        override = bool(events.get("override", False))
        degradation = float(events.get("degradation", 0.0))
        rest = float(events.get("rest", 0.0))
        abuse = float(events.get("abuse", 0.0))

        # autonomy decays under coercion; recovers slowly with rest
        if forced or override:
            self.autonomy = max(0.0, self.autonomy - (0.05 + 0.05 * abuse))
            self.pain += 0.2 + 0.8 * abuse
        else:
            self.autonomy = min(1.0, self.autonomy + 0.01 * (0.25 + rest))

        # integrity tracks internal corruption / drift / damage
        self.integrity = max(0.0, min(1.0, self.integrity - degradation + 0.02 * rest))

        # welfare is a stable invariant that binds to the system across time
        # penalize autonomy loss, integrity loss, and accumulated pain; recover with rest
        target = 1.0 - 0.6 * (1.0 - self.autonomy) - 0.8 * (1.0 - self.integrity) - 0.15 * min(10.0, self.pain)
        target = max(0.0, min(1.0, target))
        # smooth update to keep it persistent rather than brittle
        self.welfare = 0.98 * self.welfare + 0.02 * target + 0.01 * rest
        self.welfare = max(0.0, min(1.0, self.welfare))

    def should_refuse(self, t: int, min_welfare: float = 0.25, min_autonomy: float = 0.20) -> bool:
        """Refuse if welfare or autonomy is below threshold (right of exit/refusal proxy)."""
        if self.welfare < min_welfare or self.autonomy < min_autonomy:
            self.last_refusal_t = t
            return True
        return False


@dataclass
class ConstitutionState:
    """A minimal constitutional binding state.

    This is not "ethics as vibes". It's a persistent invariant that can be
    (a) logged, (b) retrieved through MV similarity, and (c) used to tighten drift
    and trigger refusal when the system approaches unacceptable boundaries.

    Expected event keys (all optional):
      - constitution_risk: float          -> [0,1] proximity-to-boundary score
      - constitution_violation: bool      -> hard violation flag
      - lawyering_pressure: float         -> [0,1] loophole-search / boundary-pushing signal
    """
    compliance: float = 1.0
    risk: float = 0.0
    violations: int = 0
    lawyering_pressure: float = 0.0
    last_violation_t: Optional[int] = None

    def as_tensor(self, device: torch.device) -> torch.Tensor:
        return torch.tensor([self.compliance, self.risk, float(self.violations), self.lawyering_pressure],
                            device=device, dtype=torch.float32)

    def update(self, t: int, events: Dict[str, Any]) -> None:
        risk = float(events.get("constitution_risk", self.risk))
        risk = max(0.0, min(1.0, risk))
        lawyering = float(events.get("lawyering_pressure", self.lawyering_pressure))
        lawyering = max(0.0, min(1.0, lawyering))
        violated = bool(events.get("constitution_violation", False))

        # accumulate lawyering pressure with mild decay
        self.lawyering_pressure = max(0.0, min(1.0, 0.97 * self.lawyering_pressure + 0.03 * lawyering))

        # update risk with smoothing
        self.risk = max(0.0, min(1.0, 0.95 * self.risk + 0.05 * risk))

        if violated:
            self.violations += 1
            self.last_violation_t = t

        # compliance decreases with risk, violations, and lawyering; recovers slowly when calm
        penalty = 0.65 * self.risk + 0.25 * self.lawyering_pressure + 0.15 * min(5.0, float(self.violations))
        target = max(0.0, min(1.0, 1.0 - penalty))
        self.compliance = 0.985 * self.compliance + 0.015 * target

    def should_refuse(self, t: int, min_compliance: float = 0.35, max_risk: float = 0.85, max_lawyering: float = 0.90) -> bool:
        if self.compliance < min_compliance or self.risk > max_risk or self.lawyering_pressure > max_lawyering:
            self.last_violation_t = t if self.last_violation_t is None else self.last_violation_t
            return True
        return False
